Usage:

convert_all.bat BASE OUTPUT_WIDTH OUTPUT_HEIGHT

Recursively converts all KSK files under the given BASE directory
into MOV files, named by appending .MOV to the KSK file name.

To tweak the MOV compression, edit the -q:X argument in convert.bat.
X is a real from 0 to 1, where 1 is least compression.
